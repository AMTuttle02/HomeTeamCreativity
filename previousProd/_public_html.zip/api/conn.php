<?php
$servername = "localhost";
$user = "u684790856_amtuttle02";
$pass = "ThisWebsiteIsForMySister1!";
$dbname = "u684790856_hometeam";
$conn = mysqli_connect($servername, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
